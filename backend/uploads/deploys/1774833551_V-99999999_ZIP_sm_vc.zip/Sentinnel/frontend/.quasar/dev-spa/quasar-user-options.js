/* eslint-disable */
/**
 * THIS FILE IS GENERATED AUTOMATICALLY.
 * DO NOT EDIT.
 *
 * You are probably looking on adding startup/initialization code.
 * Use "quasar new boot <name>" and add it there.
 * One boot file per concern. Then reference the file(s) in quasar.config file > boot:
 * boot: ['file', ...] // do not add ".js" extension to it.
 *
 * Boot files are your "main.js"
 **/

import lang from 'quasar/lang/es.js'

import iconSet from 'quasar/icon-set/material-icons.js'



import {Notify,Dialog,Loading} from 'quasar'



export default { config: {"dark":false,"brand":{"primary":"#0d7a6f","secondary":"#5bc0be","accent":"#0fa899","dark":"#0b132b","positive":"#059669","negative":"#dc2626","info":"#0284c7","warning":"#d97706"}},lang,iconSet,plugins: {Notify,Dialog,Loading} }

